#pragma once

//#define CUSTOM_PINS
//#define PIN_WIRE_SDA 23
//#define PIN_WIRE_SCL 21


//пины кнопок
#define LEFT_BTN 12
#define DOWN_BTN 11
#define UP_BTN 10
#define RIGHT_BTN 9
#define ENTER_BTN 7
#define FUNC_BTN 8


//пины дисплея
#define SI 46
#define SCL 44
#define RS 42
#define RSE 40
#define CS 38

//константы связанные с дисплеем
#define SCREEN_WIDTH 128 // ширина в пикс
#define SCREEN_HEIGHT 64 // высота в пикс
#define DATA_COL_WIDTH 26 //ширина столбца с данными (4 символа + 2 пикселя справа для бегунка)
#define FRAME_RADIUS 5    //радиус скругленной рамки

//константы связанные с структурой данных EEPROM
#define SIZE_OF_DATA 2 //размер данных хранимых в EEPROM в байтах
#define START_BYTE 10 // байт, с которого начинает храниться информация о режиме
#define PROG_FIRST_BYTE START_BYTE + 5*SIZE_OF_DATA + 1 + 1
#define NUM_OF_POINTS 16
#define NUM_OF_PROGS 8


//константы менюшек
#define MM_ITEMS 3
#define PROG_ITEMS 8
#define SETUP_ITEMS 8
#define SETTINGS_ITEMS 5
#define NUM_OF_PTS 16


#define MOTOR_STEPS 200
#define MOTOR_IN_1  3
#define MOTOR_IN_2  4
#define MOTOR_IN_3  5
#define MOTOR_IN_4  6

#define TIMER_PERIOD 10 //период таймера в милисекундах


#define SCROLL_FREQ 3  //частота обновления текста в режиме прокрутки
#define TEXT_MAX_LEN (SCREEN_WIDTH - DATA_COL_WIDTH) / 6 - 7
#define TEXT_MAX_LEN_8 TEXT_MAX_LEN - 2
#define DATA_X_BIAS 7
#define LINE_Y_BIAS -1
#define LOADING_TIME 1000

#define BUZZER 3
#define BUZZER_PITCH 25

#define PWR_LOSS 2 //INT 0

#define MAX_TIME 599
#define MAX_NUM 999

#define MAX_DECCEL 100
#define TIME_TO_STOP 1 //время (в секундах) необходмое для остановки