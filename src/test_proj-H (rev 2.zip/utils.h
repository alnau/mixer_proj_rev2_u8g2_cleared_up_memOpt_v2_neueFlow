#pragma once

#ifndef UTILS
#define UTILS
//#include "constants.h"
//#include "libs_header.h"


//возвращает true если eeprom инициализируется впервые
bool check_if_first_init() {
  uint8_t first_byte_in_EEPROM;
  bool is_it_first_init = false;
  EEPROM.get(0, first_byte_in_EEPROM);
  //на случай если заводские данные отличаются от 255 в каждом байте
  if (first_byte_in_EEPROM != 255) {
    is_it_first_init = first_byte_in_EEPROM & 0b00000001;

    return !is_it_first_init;
  }
  else
    return true;
}
#endif
